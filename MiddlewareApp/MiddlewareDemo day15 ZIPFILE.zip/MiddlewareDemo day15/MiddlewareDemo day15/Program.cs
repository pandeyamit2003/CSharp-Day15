using MiddlewareDemo.Middleware;

var builder = WebApplication.CreateBuilder(args);

var app = builder.Build();



// Middleware 1: HTTPS Redirection
app.UseHttpsRedirection();


// Middleware 2: Error Handling Middleware
app.UseMiddleware<ErrorHandlingMiddleware>();


// Middleware 3: Logging Middleware
app.UseMiddleware<LoggingMiddleware>();


// Middleware 4: Security Headers Middleware
app.UseMiddleware<SecurityHeadersMiddleware>();


// Middleware 5: Serve Static Files
app.UseStaticFiles();


// Default Route
app.MapGet("/", () => "Application Running Successfully!");


// Test Error Route
app.MapGet("/error", () =>
{
    throw new Exception("Test Exception");
});

app.Run();