﻿namespace MiddlewareDemo.Middleware
{
    public class SecurityHeadersMiddleware
    {
        private readonly RequestDelegate _next;

        // Constructor
        public SecurityHeadersMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        // Middleware Logic
        public async Task InvokeAsync(HttpContext context)
        {
            // Add Content Security Policy Header
            context.Response.Headers.Append(
                "Content-Security-Policy",
                "default-src 'self'; script-src 'self'; style-src 'self';"
            );

            await _next(context);
        }
    }
}