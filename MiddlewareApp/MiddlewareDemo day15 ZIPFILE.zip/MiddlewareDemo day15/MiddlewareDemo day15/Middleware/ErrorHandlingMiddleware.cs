﻿namespace MiddlewareDemo.Middleware
{
    public class ErrorHandlingMiddleware
    {
        private readonly RequestDelegate _next;

        // Constructor
        public ErrorHandlingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        // Middleware Logic
        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                // Call next middleware
                await _next(context);
            }
            catch (Exception)
            {
                context.Response.ContentType = "text/html";
                context.Response.StatusCode = 500;

                await context.Response.WriteAsync(@"
                    <h1>Something went wrong!</h1>
                    <p>Please try again later.</p>
                ");
            }
        }
    }
}