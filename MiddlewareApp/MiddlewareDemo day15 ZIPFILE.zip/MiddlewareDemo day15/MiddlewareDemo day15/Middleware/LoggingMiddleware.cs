﻿namespace MiddlewareDemo.Middleware
{
    public class LoggingMiddleware
    {
        private readonly RequestDelegate _next;

        // Constructor
        public LoggingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        // Middleware Logic
        public async Task InvokeAsync(HttpContext context)
        {
            Console.WriteLine("----- Incoming Request -----");

            Console.WriteLine($"Method: {context.Request.Method}");
            Console.WriteLine($"Path: {context.Request.Path}");

            // Call next middleware
            await _next(context);

            Console.WriteLine("----- Outgoing Response -----");

            Console.WriteLine($"Status Code: {context.Response.StatusCode}");
        }
    }
}